import ListaCategorias from "./ListaCategorias"
export default ListaCategorias