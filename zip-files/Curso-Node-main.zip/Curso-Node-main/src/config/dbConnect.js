import mongoose from "mongoose";


mongoose.connect("mongodb+srv://williangkk:williangk123@cursonode.hfrmc.mongodb.net/alura-node")

let db = mongoose.connection

export default db